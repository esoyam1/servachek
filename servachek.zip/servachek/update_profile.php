<?php
session_start();
require_once 'myssqconect\connect.php';

if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$id = $_SESSION['user']['id'];
$login = trim($_POST['login']);
$email = trim($_POST['email']);
$phone = trim($_POST['phone_number']);

$current_password = $_POST['current_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';
$repeat_password = $_POST['repeat_password'] ?? '';

// Получаем текущие данные пользователя
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    $_SESSION['error'] = 'Пользователь не найден';
    header('Location: edit_profile.php');
    exit();
}

// Обновление основного профиля
$updateStmt = $pdo->prepare("UPDATE users SET login = ?, email = ?, phone_number = ? WHERE id = ?");
$updateStmt->execute([$login, $email, $phone, $id]);

// Если пользователь указал смену пароля
if (!empty($current_password) || !empty($new_password) || !empty($repeat_password)) {
    if (empty($current_password) || empty($new_password) || empty($repeat_password)) {
        $_SESSION['error'] = 'Для смены пароля заполните все поля.';
        header('Location: edit_profile.php');
        exit();
    }

    if (!password_verify($current_password, $user['password'])) {
        $_SESSION['error'] = 'Старый пароль неверный.';
        header('Location: edit_profile.php');
        exit();
    }

    if ($new_password !== $repeat_password) {
        $_SESSION['error'] = 'Новый пароль и повтор не совпадают.';
        header('Location: edit_profile.php');
        exit();
    }

    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $passStmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    $passStmt->execute([$new_password_hash, $id]);
}

$_SESSION['message'] = 'Профиль успешно обновлён!';
header('Location: edit_profile.php');
exit();
