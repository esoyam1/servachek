<?php
session_start();
require_once 'myssqconect\connect.php';

$user = $_SESSION['user'] ?? null;
if (!$user) {
    header("Location: index.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user['id']]);
$currentUser = $stmt->fetch();
$avatar = $currentUser['avatar'] ?? 'https://i.pravatar.cc/150?u=' . $currentUser['id'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактирование профиля</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .card {
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        .avatar-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card p-4">
                <h2 class="mb-4 text-center">✏️ Редактирование профиля</h2>

                <?php if (!empty($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($_SESSION['error']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['error']); ?>
                <?php endif; ?>

                <?php if (!empty($_SESSION['message'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= htmlspecialchars($_SESSION['message']) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php unset($_SESSION['message']); ?>
                <?php endif; ?>

                <form method="POST" action="update_profile.php" enctype="multipart/form-data">
                    <div class="text-center mb-4">
                        <img id="avatarPreview" src="<?= htmlspecialchars($avatar) ?>" class="avatar-preview" alt="Аватар">
                        <div class="mt-2">
                            <input type="file" id="avatarInput" name="avatar" class="form-control d-none" accept="image/*">
                            <button type="button" class="btn btn-outline-primary mt-2" onclick="document.getElementById('avatarInput').click()">🖼 Изменить аватар</button>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">👤 Имя</label>
                        <input type="text" name="login" class="form-control" value="<?= htmlspecialchars($currentUser['login']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">📧 Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($currentUser['email']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">📱 Телефон</label>
                        <input type="tel" name="phone_number" class="form-control" value="<?= htmlspecialchars($currentUser['phone_number']) ?>" required>
                    </div>

                    <hr>
                    <p class="fw-semibold">🔒 Сменить пароль (необязательно):</p>

                    <div class="mb-3">
                        <label class="form-label">Старый пароль</label>
                        <input type="password" name="current_password" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Новый пароль</label>
                        <input type="password" name="new_password" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Повторите новый пароль</label>
                        <input type="password" name="repeat_password" class="form-control">
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <a href="profile.php" class="btn btn-outline-secondary">← Назад</a>
                        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const avatarInput = document.getElementById('avatarInput');
  const avatarPreview = document.getElementById('avatarPreview');

  avatarInput.addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
      avatarPreview.src = URL.createObjectURL(file);
    }
  });
</script>
</body>
</html>
