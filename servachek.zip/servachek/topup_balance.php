<?php
session_start();
require_once 'myssqconect\connect.php';

$user = $_SESSION['user'] ?? null;

if (!$user) {
    header("Location: index.php");
    exit();
}

$amount = (int)($_POST['amount'] ?? 0);

if ($amount >= 10) {
    $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->execute([$amount, $user['id']]);
    $_SESSION['success'] = "Баланс успешно пополнен на $amount ₽!";
}

header("Location: profile.php");
exit();
