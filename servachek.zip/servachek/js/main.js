function calculatePrice() {
    let total = 0;
    document.querySelectorAll('select.select').forEach(select => {
        total += parseInt(select.value || 0);
    });
    document.getElementById('price').innerText = total.toLocaleString();
}

function handleOrder() {
    const isLoggedIn = true; // Замените проверкой авторизации
    if (!isLoggedIn) {
        document.getElementById("auth-message").style.display = "block";
    } else {
        alert("Заказ оформлен!");
    }
}
