$(document).ready(function () {

    // ===== ВХОД =====
    $('.butt_login').click(function (e) {
        e.preventDefault();
        $('input').removeClass('error_fields');
        $('.msg_in').addClass('none').text('');
        $('.resend-box').remove();

        let email = $('input[name="email"]').val();
        let password = $('input[name="password"]').val();

        $.ajax({
            url: 'inc/signin.php',
            type: 'POST',
            dataType: 'json',
            data: { email, password },
            success: function (data) {
                if (data.status) {
                    location.href = '/profile.php';
                } else {
                    if (data.type === 1 && data.fields) {
                        data.fields.forEach(field => {
                            $(`input[name="${field}"]`).addClass('error_fields');
                        });
                    }
                    $('.msg_in').removeClass('none').text(data.message);

                    if (data.message.includes("Подтвердите вашу почту")) {
                        showResendButton(email);
                    }
                }
            },
            error: function () {
                $('.msg_in').removeClass('none').text('Ошибка соединения с сервером.');
            }
        });
    });

    // ===== РЕГИСТРАЦИЯ =====
    $('.butt_registration').click(function (e) {
        e.preventDefault();
        $('input').removeClass('error_fields');
        $('.msg_up').addClass('none').text('');

        let formData = new FormData();
        formData.append('email', $('input[name="email_2"]').val());
        formData.append('phone', $('input[name="phone_number_2"]').val());
        formData.append('login', $('input[name="login_2"]').val());
        formData.append('password', $('input[name="password_2"]').val());
        formData.append('repeat_password', $('input[name="repeat_password_2"]').val());

        $.ajax({
            url: 'inc/signup.php',
            type: 'POST',
            processData: false,
            contentType: false,
            data: formData,
            dataType: 'json',
            success: function (data) {
                if (data.status) {
                    $('#form-register')[0].reset();
                    $('.msg_up').removeClass('none').text(data.message).css('color', 'green');

                    // Показываем модалку подтверждения
                    $('#verify-modal').removeClass('none');

                    // Повторная отправка
                    $('#resend-verify-email').off('click').on('click', function () {
                        const email = $('input[name="email_2"]').val();
                        $('#resend-status').text('⏳ Отправка...');
                        $.post('inc/resend_email.php', { email }, function (res) {
                            if (res.status) {
                                $('#resend-status').text('✅ Письмо отправлено повторно');
                            } else {
                                $('#resend-status').text('Ошибка: ' + res.message);
                            }
                        }, 'json');
                    });

                } else {
                    $('.msg_up').removeClass('none').text(data.message).css('color', 'red');

                    if (data.type === 1 && data.fields) {
                        data.fields.forEach(field => {
                            $(`input[name="${field}_2"]`).addClass('error_fields');
                        });
                    }
                }
            },
            error: function () {
                $('.msg_up').removeClass('none').text('Ошибка при регистрации.');
            }
        });
    });

    // ===== Повторная отправка письма при входе =====
    function showResendButton(email) {
        if ($('#resend-box').length) return;

        const box = $(`
            <div class="resend-box mt-2" id="resend-box">
                <button class="btn btn-sm btn-outline-primary" id="resend-btn">🔄 Отправить письмо повторно</button>
                <span id="resend-timer" class="ms-2 text-muted"></span>
            </div>
        `);
        $('.msg_in').after(box);

        let wait = 60;
        const timer = setInterval(() => {
            wait--;
            $('#resend-timer').text(`(${wait} сек.)`);
            if (wait <= 0) {
                clearInterval(timer);
                $('#resend-btn').prop('disabled', false).text('🔄 Отправить ещё раз');
            }
        }, 1000);

        $('#resend-btn').prop('disabled', true).click(function () {
            $.post('inc/resend_email.php', { email }, function (res) {
                alert('Письмо отправлено повторно!');
            });
            $(this).prop('disabled', true).text('🔄 Отправлено...');
        });
    }

});