<?php
$host = '127.127.126.50'; // или 127.127.126.50, если это верно
$db   = 'servachek'; // 👈 база с users
$user = 'root';
$pass = '141930s@'; // или твой пароль
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die("Ошибка подключения к registeruser: " . $e->getMessage());
}
