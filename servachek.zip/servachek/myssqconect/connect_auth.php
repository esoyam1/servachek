<?php
$host = '127.127.126.50';
$user = 'root';
$password = '141930s@';
$database = 'servachek';

$connect = mysqli_connect($host, $user, $password, $database);

if (!$connect) {
    die("Ошибка подключения к БД: " . mysqli_connect_error());
}
