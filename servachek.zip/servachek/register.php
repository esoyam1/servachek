<?php
session_start();
require_once 'myssqconect\connect.php';


$user = $_SESSION['user'] ?? null;

if ($user && is_array($user)) {
    header("Location: profile.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/pretty_styles.css">
</head>
<body>

<main class="main_windows">
    <h1 class="h1_helo">Регистрация</h1>

    <div class="auth-form">
        <form id="form-register">
            <input name="email" type="email" placeholder="Электронная почта" class="form-control mb-3" required>
            <input name="phone" type="tel" placeholder="Телефон" class="form-control mb-3 pfone" required>
            <input name="login" type="text" placeholder="Имя пользователя" class="form-control mb-3" required>
            <input name="password" type="password" placeholder="Пароль" class="form-control mb-3" required>
            <input name="repeat_password" type="password" placeholder="Повторите пароль" class="form-control mb-3" required>

            <p class="msg_up text-danger mb-3"></p>

            <button type="submit" class="button_hs mb-3 w-100">Зарегистрироваться</button>
            
            <a href="login.php" class="back-link d-block text-center">🏠 Назад ко входу</a>
        </form>
    </div>
</main>

<!-- Модальное окно подтверждения -->
<div class="modal fade" id="verify-modal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content text-center">
      <div class="modal-header">
        <h5 class="modal-title">📧 Подтвердите почту</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрыть"></button>
      </div>
      <div class="modal-body">
        <p>Письмо с подтверждением отправлено на ваш email.</p>
        <button id="resend-verify-email" class="btn btn-outline-primary" disabled>
            🔁 Повторно отправить (<span id="timer">60</span> сек.)
        </button>
        <div id="resend-status" class="mt-2 text-muted"></div>
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
let verifyModal;
let countdown = 60;
let interval;

document.addEventListener("DOMContentLoaded", () => {
    $('.pfone').mask('+7 (000) 000-00-00', { placeholder: "+7 (___) ___-__-__" });
    verifyModal = new bootstrap.Modal(document.getElementById('verify-modal'));

    document.getElementById('form-register').addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        fetch('inc/signup.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status) {
                document.querySelector('.msg_up').textContent = data.message;
                showVerifyModal();
                this.reset();
            } else {
                document.querySelector('.msg_up').textContent = data.message;
            }
        });
    });
});

function showVerifyModal() {
    document.getElementById('resend-verify-email').disabled = true;
    document.getElementById('resend-status').textContent = '';
    document.getElementById('timer').textContent = countdown;
    verifyModal.show();

    clearInterval(interval);
    countdown = 60;
    interval = setInterval(() => {
        countdown--;
        document.getElementById('timer').textContent = countdown;
        if (countdown <= 0) {
            clearInterval(interval);
            document.getElementById('resend-verify-email').disabled = false;
            document.getElementById('resend-verify-email').textContent = "🔁 Отправить повторно";
        }
    }, 1000);

    document.getElementById('resend-verify-email').onclick = () => {
        const email = document.querySelector('input[name="email"]').value;
        document.getElementById('resend-status').textContent = "⏳ Отправка...";
        fetch("inc/resend_email.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "email=" + encodeURIComponent(email)
        })
        .then(res => res.json())
        .then(data => {
            document.getElementById('resend-status').textContent = data.status
                ? "✅ Письмо отправлено"
                : "❌ Ошибка: " + data.message;
        });
    };
}
</script>

</body>
</html>
