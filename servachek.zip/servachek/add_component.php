<?php
require_once 'myssqconect\connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = $_POST['category'];
    $name = $_POST['name'];
    $price = $_POST['price'];

    $stmt = $pdo->prepare("INSERT INTO components (category, name, price) VALUES (?, ?, ?)");
    $stmt->execute([$category, $name, $price]);

    header("Location: admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавить компонент</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h4 class="mb-4">➕ Добавить компонент</h4>
    <form method="post">
        <input type="text" name="category" class="form-control mb-2" placeholder="Категория" required>
        <input type="text" name="name" class="form-control mb-2" placeholder="Название" required>
        <input type="number" name="price" class="form-control mb-3" placeholder="Цена" required>
        <button class="btn btn-success">Добавить</button>
        <a href="admin.php" class="btn btn-secondary">Назад</a>
    </form>
</body>
</html>
