<?php
session_start();
require_once 'myssqconect/connect.php';

$user = $_SESSION['user'] ?? null;

if ($user && is_array($user)) {
    header("Location: profile.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход</title>
    <link rel="stylesheet" href="css/pretty_styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>

<main class="main_windows">
    <h1 class="h1_helo">Вход в личный кабинет</h1>

    <div class="auth-form">
    <form id="form-login">
        <input name="email" type="email" placeholder="Электронная почта" required>
        <input name="password" type="password" placeholder="Пароль" required>
        <p class="msg_in none" style="color: red; margin-top: 10px;"></p>
        <button type="submit" class="button_hs">Войти</button>
    </form>
</div>
            <a href="index.php" class="back-link">
    🏠На главную
</a>
        </div>
    </form>
</main>

<!-- JS -->
<script src="js/jquery-3.7.1.min.js"></script>
<script>
$('.butt_login').click(function (e) {
    e.preventDefault();

    let email = $('input[name="email"]').val();
    let password = $('input[name="password"]').val();

    $.ajax({
        url: 'inc/signin.php',
        type: 'POST',
        dataType: 'json',
        data: { email, password },
        success: function (data) {
            if (data.status) {
                location.href = '/profile.php';
            } else {
                $('.msg_in').removeClass('none').text(data.message);
            }
        },
        error: function () {
            $('.msg_in').removeClass('none').text('Ошибка сервера. Повторите попытку.');
        }
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("form-login");
    const msgBlock = document.querySelector(".msg_in");

    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const formData = new FormData(loginForm);
        fetch("inc/signin.php", {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status) {
                window.location.href = "profile.php";
            } else {
                msgBlock.textContent = data.message;
                msgBlock.classList.remove("none");
            }
        })
        .catch(() => {
            msgBlock.textContent = "Ошибка соединения с сервером.";
            msgBlock.classList.remove("none");
        });
    });
});
</script>

</body>
</html>
