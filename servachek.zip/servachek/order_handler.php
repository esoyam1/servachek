<?php
session_start();
require_once 'myssqconect\connect.php';

header('Content-Type: application/json');

// Проверка авторизации
if (!isset($_SESSION['user']['id'])) {
    echo json_encode([
        'status' => false,
        'message' => 'Вы не авторизованы.'
    ]);
    exit();
}

$user_id = $_SESSION['user']['id'];
$cpu = trim($_POST['cpu'] ?? '');
$ram = trim($_POST['ram'] ?? '');
$gpu = trim($_POST['gpu'] ?? '');
$disk = trim($_POST['disk'] ?? '');
$price = intval($_POST['price'] ?? 0);

// Валидация
if (!$cpu || !$ram || !$disk || $price <= 0) {
    echo json_encode([
        'status' => false,
        'message' => 'Заполните все обязательные поля.'
    ]);
    exit();
}

// Формируем конфигурацию
$name = "CPU: $cpu | RAM: $ram" . ($gpu ? " | GPU: $gpu" : "") . " | Disk: $disk";

try {
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, name, price) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $name, $price]);

    echo json_encode([
        'status' => true,
        'message' => 'Заказ успешно оформлен!'
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'status' => false,
        'message' => 'Ошибка при сохранении заказа: ' . $e->getMessage()
    ]);
}
?>
