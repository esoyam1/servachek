<?php
session_start();
require_once 'myssqconect\connect.php';


$user = $_SESSION['user'] ?? null;
if (!$user) {
    header("Location: index.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user['id']]);
$currentUser = $stmt->fetch();
$avatar = $currentUser['avatar'] ?? 'https://i.pravatar.cc/150?u=' . $currentUser['id'];
$balance = $currentUser['balance'] ?? 0;

// Пример уведомлений (в реальном проекте — из базы)
$notifications = [
    ['type' => 'success', 'title' => 'Заказ #123', 'message' => 'Ваш заказ готов к выдаче.'],
    ['type' => 'success', 'title' => 'Баланс', 'message' => 'Счёт успешно пополнен на 500 ₽.'],
    ['type' => 'warning', 'title' => 'Безопасность', 'message' => 'Вход выполнен с нового устройства.']
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Профиль пользователя</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f6f8fa;
        }
        .sidebar {
            height: 100%;
            padding: 2rem 1rem;
            background-color: #fff;
            border-right: 1px solid #e1e4e8;
        }
        .profile-avatar {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            border: 1px solid #d1d5da;
        }
        .toast-container {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1055;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 sidebar">
            <div class="text-center mb-4">
                <img src="<?= htmlspecialchars($avatar) ?>" class="profile-avatar mb-3" alt="Avatar">
                <h4><?= htmlspecialchars($currentUser['login']) ?></h4>
                <p class="text-muted mb-0"><?= htmlspecialchars($currentUser['email']) ?></p>
                <p class="text-muted"><?= htmlspecialchars($currentUser['phone_number']) ?></p>
                <a href="edit_profile.php" class="btn btn-outline-secondary mt-2 w-100">Редактировать профиль</a>
                <a href="logout.php" class="btn btn-danger mt-2 w-100">Выйти</a>
            </div>
            <hr>
            <ul class="nav flex-column">
                <li class="nav-item">
                <a class="nav-link active" href="index.php">🏠 Главная страница</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="orders.php">📦Заказы</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" id="showNotifications">🔔Проверить уведомления</a>
                </li>
                </ul>
        </nav>

        <!-- Main content -->
        <main class="col-md-9 p-4">
            <div class="profile-header mb-4">
                <h3>Добро пожаловать, <?= htmlspecialchars($currentUser['login']) ?> 👋</h3>
                <p class="text-muted">Это ваш персональный дашборд</p>
            </div>

            <div class="row g-4 mt-3">
    <!-- Заказы -->
    <div class="col-md-4">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">📦 Заказы</h5>
          <p class="card-text">История заказов: <strong>12</strong></p>
          <a href="orders.php" class="btn btn-outline-primary btn-sm">Посмотреть</a>
        </div>
      </div>
    </div>

    <!-- Серверы -->
    <div class="col-md-4">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">🖥️ Серверы</h5>
          <p class="card-text">Арендуй сервер</p>
          <a href="servers.php" class="btn btn-outline-primary btn-sm">Перейти</a>
        </div>
      </div>
    </div>

    <!-- Баланс -->
    <div class="col-md-4">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title">💰 Баланс</h5>
          <p class="card-text">Текущий баланс: <strong><?= number_format($balance, 2, ',', ' ') ?> ₽</strong></p>
          <a href="topup_balance.php" class="btn btn-outline-success btn-sm">Пополнить</a>
        </div>
      </div>
    </div>

    <?php if ($currentUser['id'] == 0): ?>
    <!-- Админка (только для admin) -->
    <div class="col-md-4">
      <div class="card shadow-sm h-100 border-danger">
        <div class="card-body">
          <h5 class="card-title text-danger">🔐 Админка</h5>
          <p class="card-text">Управление пользователями, серверами и базой</p>
          <a href="admin.php" class="btn btn-danger btn-sm">Войти в админку</a>
        </div>
      </div>
    </div>
    <?php endif; ?>
</div>
                        

<!-- Toast notifications -->
<div class="toast-container" id="toastContainer">
    <?php foreach ($notifications as $note): ?>
        <div class="toast align-items-center text-bg-<?= $note['type'] ?> border-0 mb-3" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    <strong><?= $note['title'] ?>:</strong> <?= $note['message'] ?>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('showNotifications').addEventListener('click', function (e) {
        e.preventDefault();
        const toastElements = document.querySelectorAll('.toast');
        toastElements.forEach(toastEl => new bootstrap.Toast(toastEl).show());
    });
</script>
</body>
</html>
