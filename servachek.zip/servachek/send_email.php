<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // путь к автозагрузке Composer

function sendConfirmationEmail($toEmail, $verifyLink) {
    $mail = new PHPMailer(true);
    
    try {
        // Настройки SMTP Mail.ru
        $mail->isSMTP();
        $mail->Host       = 'smtp.mail.ru';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'xbox.or@mail.ru';     // 👈 ваш адрес mail.ru
        $mail->Password   = 'erfnVN92DQ7u7RLcLJ9c';        // 👈 пароль приложения из mail.ru (не обычный)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // От кого
        $mail->setFrom('noreply@servachek.ru', 'Servachek');

        // Кому
        $mail->addAddress($toEmail);

        // Контент
        $mail->isHTML(true);
        $mail->Subject = 'Подтверждение почты';
        $mail->Body    = "
            <h3>Здравствуйте!</h3>
            <p>Пожалуйста, подтвердите вашу почту, перейдя по ссылке:</p>
            <a href='$verifyLink'>$verifyLink</a>
            <p>Если вы не регистрировались, просто игнорируйте это письмо.</p>
        ";

        $mail->send();
        return true;

    } catch (Exception $e) {
        return $mail->ErrorInfo;
    }
}
