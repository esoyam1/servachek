<?php
require 'myssqconect\connect.php';
$id = $_GET['id'];
$pdo->prepare("DELETE FROM ready_servers WHERE id = ?")->execute([$id]);
header("Location: admin.php");
