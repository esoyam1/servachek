<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Контакты</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f8f9fa;
    }
    .contact-section {
      padding: 60px 0;
    }
    .contact-info h5 {
      margin-bottom: 10px;
    }
    .contact-form {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
  </style>
</head>
<body>

<div class="container contact-section">
  <h1 class="text-center mb-5">📬 Свяжитесь с нами</h1>

  <div class="row g-5">
    <div class="col-md-6 contact-info">
      <h5>📧 Email</h5>
      <p><a href="mailto:support@servachek.ru">support@servachek.ru</a></p>

      <h5>📞 Телефон</h5>
      <p><a href="tel:+79991234567">+7 (999) 123-45-67</a></p>

      <h5>📍 Адрес</h5>
      <p>г. Москва, ул. Серверная, д. 42, оф. 3Б</p>

      <h5>🕑 Время работы</h5>
      <p>Пн–Пт: 10:00 – 18:00<br>Сб–Вс: Выходной</p>
    </div>

    <div class="col-md-6">
      <div class="contact-form">
        <h5 class="mb-3">Форма обратной связи</h5>
        <form method="POST" action="send_message.php">
          <div class="mb-3">
            <input type="text" name="name" class="form-control" placeholder="Ваше имя" required>
          </div>
          <div class="mb-3">
            <input type="email" name="email" class="form-control" placeholder="Ваш email" required>
          </div>
          <div class="mb-3">
            <textarea name="message" class="form-control" rows="4" placeholder="Ваше сообщение" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary w-100">Отправить сообщение</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
