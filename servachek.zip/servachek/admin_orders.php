<?php
session_start();
require_once 'myssqconect\connect.php'; // подключение к БД registeruser

$user = $_SESSION['user'] ?? null;

// Только админ (id = 0)
if (!$user || $user['id'] != 0) {
    header("Location: index.php");
    exit();
}

// Обновление статуса заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], $_POST['order_id']]);
}

// Получение всех заказов
$orders = $pdo->query("
    SELECT o.*, u.login, u.email, u.phone_number
    FROM orders o
    JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заказы пользователей</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5">
    <div class="container">
        <h1 class="mb-4">📦 Все заказы пользователей</h1>

        <?php foreach ($orders as $order): ?>
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($order['name']) ?> — <?= $order['price'] ?>₽</h5>
                    <p class="card-text">
                        <strong>Пользователь:</strong> <?= htmlspecialchars($order['login']) ?><br>
                        <strong>Email:</strong> <?= htmlspecialchars($order['email']) ?><br>
                        <strong>Телефон:</strong> <?= htmlspecialchars($order['phone_number']) ?><br>
                        <strong>Дата:</strong> <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?><br>
                        <strong>Статус:</strong> <span class="badge bg-secondary"><?= $order['status'] ?></span>
                    </p>

                    <form method="POST" class="row row-cols-lg-auto g-2 align-items-center">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <div class="col-auto">
                            <select name="status" class="form-select">
                                <?php foreach (['Новый', 'В обработке', 'Выполнен', 'Отменён'] as $status): ?>
                                    <option value="<?= $status ?>" <?= $order['status'] === $status ? 'selected' : '' ?>>
                                        <?= $status ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary">💾 Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>

        <a href="admin.php" class="btn btn-outline-secondary">← Назад в админку</a>
    </div>
</body>
</html>
