<?php
session_start();
require_once 'myssqconect/connect.php';

$user = $_SESSION['user'] ?? null;
if (!$user) {
    header("Location: index.php");
    exit();
}

$stmt = $pdo->prepare("
    SELECT o.id, o.name, o.price, o.status, o.created_at
    FROM orders o
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
");
$stmt->execute([$user['id']]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мои заказы</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .order-card {
            margin-bottom: 1rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .order-status {
            font-weight: bold;
        }
    </style>
</head>
<body class="p-4">
    <div class="container">
        <h1 class="mb-4">📦 Мои заказы</h1>

        <?php if (empty($orders)): ?>
            <div class="alert alert-info" role="alert">
                У вас пока нет заказов.
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
                <div class="card order-card">
                    <div class="card-body">
                        <h5 class="card-title">Заказ #<?= htmlspecialchars($order['id']) ?></h5>
                        <p class="card-text">
                            <strong>Конфигурация:</strong> <?= htmlspecialchars($order['name']) ?><br>
                            <strong>Цена:</strong> <?= htmlspecialchars($order['price']) ?> ₽<br>
                            <strong>Дата:</strong> <?= date('d.m.Y H:i', strtotime($order['created_at'])) ?><br>
                            <strong>Статус:</strong> <span class="order-status <?= strtolower(str_replace(' ', '-', $order['status'])) ?>"><?= htmlspecialchars($order['status']) ?></span>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <a href="profile.php" class="btn btn-outline-secondary mt-3">← Назад в профиль</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>