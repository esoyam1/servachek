<?php
session_start();
require_once 'myssqconect/connect.php';

$user = $_SESSION['user'] ?? null;
if (!$user) {
    $_SESSION['error'] = 'Пожалуйста, авторизуйтесь для заказа сервера.';
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    $_SESSION['error'] = 'Не указан сервер для заказа.';
    header("Location: servers.php");
    exit();
}

$serverId = (int)$_GET['id'];

// Получаем информацию о сервере
$stmt = $pdo->prepare("SELECT title, price FROM ready_servers WHERE id = ?");
$stmt->execute([$serverId]);
$server = $stmt->fetch();

if (!$server) {
    $_SESSION['error'] = 'Сервер не найден.';
    header("Location: servers.php");
    exit();
}

// Проверяем баланс пользователя
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user['id']]);
$balance = (int)$stmt->fetchColumn();

if ($balance < $server['price']) {
    $_SESSION['error'] = 'Недостаточно средств на балансе. Пополните баланс.';
    header("Location: balance_topup.php");
    exit();
}

try {
    // Начинаем транзакцию
    $pdo->beginTransaction();

    // Создаём заказ
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, name, price, status, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->execute([$user['id'], $server['title'], $server['price'], 'Новый']);

    // Вычитаем стоимость из баланса
    $newBalance = $balance - $server['price'];
    $stmt = $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?");
    $stmt->execute([$newBalance, $user['id']]);

    // Фиксируем транзакцию
    $pdo->commit();

    $_SESSION['message'] = '✅ Заказ сервера "' . htmlspecialchars($server['title']) . '" успешно оформлен!';
    header("Location: servers.php");
    exit();
} catch (PDOException $e) {
    $pdo->rollBack();
    $_SESSION['error'] = 'Ошибка при оформлении заказа: ' . $e->getMessage();
    header("Location: servers.php");
    exit();
}
?>