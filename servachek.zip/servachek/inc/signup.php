<?php
session_start();
require_once __DIR__ . '/../myssqconect/connect_auth.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Получаем и обрабатываем поля
$email    = trim($_POST['email'] ?? '');
$phone    = trim($_POST['phone'] ?? '');
$login    = trim($_POST['login'] ?? '');
$password = $_POST['password'] ?? '';
$repeat_password = $_POST['repeat_password'] ?? '';

$errors = [];

// === ВАЛИДАЦИЯ ===
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'email';
if (empty($phone)) {
    $errors[] = 'phone';
} else {
    // Приводим к формату +7XXXXXXXXXX
    $phone = preg_replace('/\D+/', '', $phone); // оставим только цифры
    if (strlen($phone) === 11 && $phone[0] === '8') {
        $phone = '+7' . substr($phone, 1);
    } elseif (strlen($phone) === 11 && $phone[0] === '7') {
        $phone = '+7' . substr($phone, 1);
    } elseif (strlen($phone) === 10) {
        $phone = '+7' . $phone;
    } elseif (strlen($phone) !== 12 || strpos($phone, '+7') !== 0) {
        $errors[] = 'phone';
    }
}

if (empty($login) || !preg_match("/^[а-яА-ЯёЁa-zA-Z0-9]{3,30}$/u", $login)) $errors[] = 'login';
if (empty($password) || strlen($password) < 6) $errors[] = 'password';
if ($password !== $repeat_password) {
    echo json_encode([
        "status" => false,
        "type" => 1,
        "message" => "Пароли не совпадают",
        "fields" => ['repeat_password']
    ]);
    exit();
}

if (!empty($errors)) {
    echo json_encode([
        "status" => false,
        "type" => 1,
        "message" => "Проверьте правильность заполнения полей",
        "fields" => $errors
    ]);
    exit();
}

// === ПРОВЕРКА НА УНИКАЛЬНОСТЬ ===
$stmt = $connect->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode([
        "status" => false,
        "type" => 1,
        "message" => "Пользователь с такой почтой уже существует",
        "fields" => ['email']
    ]);
    exit();
}
$stmt->close();

$stmt = $connect->prepare("SELECT id FROM users WHERE phone_number = ?");
$stmt->bind_param("s", $phone);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode([
        "status" => false,
        "type" => 1,
        "message" => "Пользователь с таким номером уже существует",
        "fields" => ['phone']
    ]);
    exit();
}
$stmt->close();

// === ХЕШИРОВАНИЕ ПАРОЛЯ ===
$password_hash = password_hash($password, PASSWORD_DEFAULT);
$email_hash = md5($email . time());

// === СОХРАНЕНИЕ ПОЛЬЗОВАТЕЛЯ ===
$stmt = $connect->prepare("INSERT INTO users (email, phone_number, login, password, email_hash, email_verification) VALUES (?, ?, ?, ?, ?, 0)");
$stmt->bind_param("sssss", $email, $phone, $login, $password_hash, $email_hash);
$stmt->execute();
$stmt->close();

// === ОТПРАВКА ПИСЬМА ===
$verify_link = "http://servachek.local/verify_email.php?hash=$email_hash";
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.mail.ru';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'xbox.or@mail.ru';
    $mail->Password   = 'erfnVN92DQ7u7RLcLJ9c'; // ⚠️ безопаснее хранить в .env
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->CharSet    = 'UTF-8';

    $mail->setFrom('xbox.or@mail.ru', 'Servachek');
    $mail->addAddress($email, $login);
    $mail->isHTML(true);
    $mail->Subject = 'Подтверждение почты';
    $mail->Body    = "
        <h3>Здравствуйте, $login!</h3>
        <p>Подтвердите вашу почту, перейдя по ссылке:</p>
        <a href='$verify_link'>$verify_link</a>
        <br><br><small>Если вы не регистрировались — просто проигнорируйте это письмо.</small>
    ";

    $mail->send();

    echo json_encode([
        "status" => true,
        "message" => "✅ Регистрация успешна! Подтвердите почту через письмо."
    ]);
} catch (Exception $e) {
    echo json_encode([
        "status" => false,
        "message" => "Ошибка отправки письма: {$mail->ErrorInfo}"
    ]);
}

