<?php
require_once __DIR__ . '/../myssqconect/connect_auth.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

$email = $_POST['email'] ?? '';
$email = trim($email);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => false, "message" => "Некорректный email"]);
    exit();
}

// Найдём пользователя
$result = mysqli_query($connect, "SELECT * FROM users WHERE email = '$email'");
$user = mysqli_fetch_assoc($result);

if (!$user) {
    echo json_encode(["status" => false, "message" => "Пользователь не найден"]);
    exit();
}

if ((int)$user['email_verification'] === 1) {
    echo json_encode(["status" => false, "message" => "Почта уже подтверждена"]);
    exit();
}

$email_hash = $user['email_hash'];
$verify_link = "http://servachek.local/verify_email.php?hash=$email_hash";

// Отправка через PHPMailer
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.mail.ru';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'xbox.or@mail.ru'; // твой логин
    $mail->Password   = 'erfnVN92DQ7u7RLcLJ9c'; // пароль приложения Mail.ru
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->CharSet    = 'UTF-8';

    $mail->setFrom('xbox.or@mail.ru', 'Servachek');
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Повторное подтверждение почты';
    $mail->Body    = "
        <h3>Подтверждение аккаунта</h3>
        <p>Перейдите по ссылке для подтверждения:</p>
        <a href='$verify_link'>$verify_link</a>
        <br><br><small>Если вы не регистрировались — проигнорируйте письмо.</small>
    ";

    $mail->send();

    echo json_encode(["status" => true, "message" => "Письмо отправлено повторно"]);
} catch (Exception $e) {
    echo json_encode([
        "status" => false,
        "message" => "Ошибка отправки: {$mail->ErrorInfo}"
    ]);
}
