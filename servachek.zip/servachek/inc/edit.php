<?php
global $connect;
session_start();
require_once 'myssqconect\connect.php';
$email_3 = $_POST['email_3'];
$phone_number_3 = $_POST['phone_number_3'];
$password_new_3 = $_POST['password_new_3'];
$repeat_password_new_3 = $_POST['repeat_password_new_3'];
$password_3 = $_POST['password_3'];
$check_email = mysqli_query($connect, query:"SELECT * FROM `users` WHERE `email` = '$email_3'");
if (mysqli_num_rows($check_email) > 0) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Почта занята",
        "fields" => ['email']
    ];

    echo json_encode($edit);
    die();
}
$check_phone_number = mysqli_query($connect, query:"SELECT * FROM `users` WHERE `phone_number` = '$phone_number_3'");
if (mysqli_num_rows($check_phone_number) > 0) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Номер телефона занят",
        "fields" => ['phone_number']
    ];

    echo json_encode($edit);
    die();
}
$error_edit = [];
if ($email_3 === '') {
    $error_edit[] = 'email_3';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Введите эмайл",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($email_3 === '' || !filter_var($email_3, filter: FILTER_VALIDATE_EMAIL)) {
    $error_edit[] = 'email_3';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Неверный эмайл",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($phone_number_3 === '') {
    $error_edit[] = 'phone_number_3';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Введите номер телефона.",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($phone_number_3 === '' || !preg_match("/^((8)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{11}$/", $phone_number_3)) {
    $error_edit[] = 'phone_number_3';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Некорректный номер телефона.",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($password_new_3 === '') {
    $error_edit[] = 'password_new_3';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Введите пароль",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($password_new_3 === '' || !preg_match("/^[a-zA-Z0-9\!\@\#\$\%\^\&\*\(\)\_\+\`\~\\\|\]\}\[\{\'\"\;\:\/\?\.\>\,\<\№\=\-\/]/i", $password_new_3)) {
    $error_edit[] = 'password_new_3';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Некоректный пороль толко кирилица, цыфры и символы",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($repeat_password_new_3 === '') {
    $error_edit[] = 'repeat_password_new_3';
}
if (!empty($error_editn)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Введите повторный пароль",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}
if ($repeat_password_new_3 === '' || !preg_match("/^[a-zA-Z0-9\!\@\#\$\%\^\&\*\(\)\_\+\`\~\\\|\]\}\[\{\'\"\;\:\/\?\.\>\,\<\№\=\-\/]/i", $repeat_password_new_3)) {
    $error_edit[] = 'repeat_password_2';
}
if (!empty($error_edit)) {
    $edit = [
        "status" => false,
        "type" => 1,
        "message" => "Некоректный пороль толко кирилица, цыфры и символы",
        "fields" => $error_edit
    ];
    echo json_encode($edit);
    die();
}





if ($password_new_3 === $repeat_password_new_3) {
    $password_3 = md5($password_3);
    mysqli_query($connect, "INSERT INTO `users` (email, phone_number, login, password) VALUES ('$email_3', '$phone_number_3', '$password_3')");
    $registration = [
        "status" => true,
        "message" => "Профиль изменен",
    ];
    echo json_encode($registration);
} else {
    $registration= [
        "status" => false,
        "message" => "Пароли не совпадают",
    ];
    echo json_encode($registration);
}
?>