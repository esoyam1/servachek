<?php
session_start();
require_once __DIR__ . '/../myssqconect/connect_auth.php';

$email = $_POST['email'];
$password = $_POST['password'];

$errors = [];

if (empty($email)) $errors[] = 'email';
if (empty($password)) $errors[] = 'password';

if (!empty($errors)) {
    echo json_encode([
        "status" => false,
        "type" => 1,
        "message" => "Заполните все поля",
        "fields" => $errors
    ]);
    exit();
}

$result = mysqli_query($connect, "SELECT * FROM `users` WHERE `email` = '$email'");
$user = mysqli_fetch_assoc($result);

if (!$user || !password_verify($password, $user['password'])) {
    echo json_encode([
        "status" => false,
        "message" => "Неверный логин или пароль"
    ]);
    exit();
}

// ✅ Проверка подтверждения email
if ($user['email_verification'] != 1) {
    echo json_encode([
        "status" => false,
        "message" => "❗ Подтвердите вашу почту, прежде чем войти"
    ]);
    exit();
}

// Авторизация
$_SESSION['user'] = [
    "id" => $user['id'],
    "name" => $user['login'],
    "email" => $user['email'],
    "phone" => $user['phone_number']
];

echo json_encode(["status" => true]);
?>
