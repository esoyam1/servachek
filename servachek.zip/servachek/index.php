<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <h1 class="logo">Мой Сайт</h1>
            <nav class="navigation">
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="about.php">О нас</a></li>
                    <li><a href="contact.php">Контакты</a></li>
                    <?php if (isset($_SESSION['user'])): ?>
                        <li><a href="profile.php">Профиль</a></li>
                        <li><a href="logout.php">Выход</a></li>
                    <?php else: ?>
                        <li><a href="login.php">Вход</a></li>
                        <li><a href="register.php">Регистрация</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main class="main-content container">
        <section class="hero">
            <h2>Добро пожаловать на наш сайт!</h2>
            <p>Мы предлагаем лучшие решения для вашего бизнеса.</p>
            <a href="services.php" class="btn">Наши услуги</a>
        </section>

        <section class="features">
            <div class="feature">
                <h3>Качество</h3>
                <p>Мы гарантируем высокое качество предоставляемых услуг.</p>
            </div>
            <div class="feature">
                <h3>Надёжность</h3>
                <p>Наши решения проверены временем и клиентами.</p>
            </div>
            <div class="feature">
                <h3>Поддержка</h3>
                <p>Круглосуточная поддержка для всех наших клиентов.</p>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Мой Сайт. Все права защищены.</p>
        </div>
    </footer>
</body>
</html>
