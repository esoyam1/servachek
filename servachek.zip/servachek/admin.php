
<?php
session_start();
require_once 'myssqconect\connect.php';

$user = $_SESSION['user'] ?? null;
if (!$user || $user['id'] != 0) {
    header("Location: index.php");
    exit();
}

$components = $pdo->query("SELECT * FROM components ORDER BY category, name")->fetchAll();
$readyServers = $pdo->query("SELECT * FROM ready_servers ORDER BY title")->fetchAll();
$categories = $pdo->query("SELECT DISTINCT category FROM components")->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админ-панель</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .section-title { border-bottom: 1px solid #dee2e6; padding-bottom: .5rem; margin-bottom: 1rem; }
        .form-popup { background: #fff; border: 1px solid #ccc; padding: 20px; border-radius: 6px; margin-bottom: 20px; }
    </style>
</head>
<body>
<a href="profile.php" class="btn btn-outline-secondary m-3">← Назад в профиль</a>

<div class="container py-4">
    <h4 class="mb-4">👑 Админ-панель</h4>

    <!-- Добавление компонента -->
    <div class="form-popup">
        <h5>➕ Добавить компонент</h5>
        <form method="post" action="add_component.php">
            <div class="mb-2">
                <label>Категория:</label>
                <select class="form-select" name="category" id="categorySelect">
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
                    <?php endforeach; ?>
                    <option value="__new__">Другая (ввести)</option>
                </select>
                <input type="text" class="form-control mt-2 d-none" name="new_category" id="newCategoryInput" placeholder="Введите новую категорию">
            </div>
            <div class="mb-2">
                <input type="text" class="form-control" name="name" placeholder="Название компонента" required>
            </div>
            <div class="mb-2">
                <input type="number" class="form-control" name="price" placeholder="Цена в ₽" required>
            </div>
            <button type="submit" class="btn btn-success">Добавить</button>
        </form>
    </div>

    <!-- Компоненты -->
    <div class="mb-5">
        <div class="section-title">
            <h5>🧩 Компоненты</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle">
                <thead class="table-light">
                    <tr><th>ID</th><th>Категория</th><th>Название</th><th>Цена (₽)</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($components as $comp): ?>
                        <tr>
                            <td><?= $comp['id'] ?></td>
                            <td><?= htmlspecialchars($comp['category']) ?></td>
                            <td><?= htmlspecialchars($comp['name']) ?></td>
                            <td><?= number_format($comp['price'], 0, ',', ' ') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Добавление сервера -->
    <div class="form-popup">
        <h5>➕ Добавить сервер</h5>
        <form method="post" action="/add_ready_server.php">
            <div class="mb-2">
                <input type="text" class="form-control" name="title" placeholder="Название сервера" required>
            </div>
            <div class="mb-2">
                <textarea class="form-control" name="description" placeholder="Описание" required></textarea>
            </div>
            <div class="mb-2">
                <input type="number" class="form-control" name="price" placeholder="Цена (₽/мес)" required>
            </div>
            <button type="submit" class="btn btn-success">Добавить сервер</button>
        </form>
    </div>

    <!-- Список серверов -->
    <div>
        <div class="section-title">
            <h5>🖥 Готовые серверы</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle">
                <thead class="table-light">
                    <tr><th>ID</th><th>Название</th><th>Описание</th><th>Цена (₽/мес)</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($readyServers as $srv): ?>
                        <tr>
                            <td><?= $srv['id'] ?></td>
                            <td><?= htmlspecialchars($srv['title']) ?></td>
                            <td><?= htmlspecialchars($srv['description']) ?></td>
                            <td><?= number_format($srv['price'], 0, ',', ' ') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.getElementById('categorySelect').addEventListener('change', function () {
    const newCategoryInput = document.getElementById('newCategoryInput');
    newCategoryInput.classList.toggle('d-none', this.value !== '__new__');
    if (this.value !== '__new__') newCategoryInput.value = '';
});
</script>
</body>
</html>
