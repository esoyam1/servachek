<?php
require_once 'myssqconect\connect_auth.php';

$hash = $_GET['hash'] ?? '';
$success = false;

if ($hash) {
    $stmt = mysqli_prepare($connect, "SELECT id FROM users WHERE email_hash = ? AND email_verification = 0");
    mysqli_stmt_bind_param($stmt, "s", $hash);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        mysqli_query($connect, "UPDATE users SET email_verification = 1 WHERE id = " . $user['id']);
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Подтверждение почты</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: 'Inter', sans-serif;
        }
        .verify-box {
            background: white;
            border-radius: 10px;
            padding: 40px;
            max-width: 500px;
            text-align: center;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            animation: fadeIn 0.6s ease-in-out;
        }
        .verify-box h2 {
            color: #2dce89;
        }
        .verify-box p {
            color: #555;
        }
        .btn-home {
            margin-top: 20px;
            background-color: #2dce89;
            color: white;
            border: none;
        }
        .btn-home:hover {
            background-color: #24b97b;
        }
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(20px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
    <?php if ($success): ?>
        <meta http-equiv="refresh" content="5;url=index.php">
    <?php endif; ?>
</head>
<body>

<div class="verify-box">
    <?php if ($success): ?>
        <h2>✅ Почта подтверждена</h2>
        <p>Вы будете перенаправлены на главную через 5 секунд...</p>
    <?php else: ?>
        <h2>❌ Ошибка</h2>
        <p>Ссылка недействительна или уже была использована.</p>
    <?php endif; ?>

    <a href="index.php" class="btn btn-home">🔙 На главную</a>
</div>

</body>
</html>
