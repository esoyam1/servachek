<?php
session_start();

// Настройки
$to = "support@servachek.ru"; // Замените на ваш email
$subject = "Новое сообщение с сайта";

// Проверка метода
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Метод не разрешён");
}

// Honeypot
if (!empty($_POST['username'])) {
    exit("Бот обнаружен.");
}

// Получение данных
$name = htmlspecialchars(trim($_POST['name'] ?? ""));
$email = filter_var(trim($_POST['email'] ?? ""), FILTER_SANITIZE_EMAIL);
$message = htmlspecialchars(trim($_POST['message'] ?? ""));

// Проверка
if (!$name || !$email || !$message || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['success'] = "❗ Пожалуйста, заполните все поля корректно.";
    header("Location: contacts.php");
    exit;
}

// Формируем тело письма
$body = "Имя: $name\n";
$body .= "Email: $email\n";
$body .= "Сообщение:\n$message\n";

// Заголовки
$headers = "From: $name <$email>\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

// Отправка
if (mail($to, $subject, $body, $headers)) {
    $_SESSION['success'] = "✅ Ваше сообщение отправлено!";
} else {
    $_SESSION['success'] = "❌ Не удалось отправить сообщение.";
}

header("Location: contacts.php");
exit;
