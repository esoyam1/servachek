<?php
session_start();
require_once 'myssqconect\connect.php'; // здесь $pdo

$user = $_SESSION['user'] ?? null;
if (!$user) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Пополнение баланса</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">💳 Пополнение баланса</h2>

    <form method="POST" action="topup_balance.php">
        <div class="mb-3">
            <label for="amount" class="form-label">Введите сумму (₽)</label>
            <input type="number" name="amount" id="amount" class="form-control" min="1" step="1" required>
        </div>

        <!-- Для тестов можно просто перекидывать -->
        <button type="submit" class="btn btn-success">Пополнить</button>
        <a href="profile.php" class="btn btn-secondary">Назад в профиль</a>
    </form>
</div>
</body>
</html>
