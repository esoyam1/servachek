<?php
session_start();
require_once 'myssqconect\connect.php';    // база registeruser


$user = $_SESSION['user'] ?? null;

if (!$user || !isset($_POST['config'])) {
    echo json_encode(['status' => false, 'message' => 'Данные не переданы']);
    exit();
}

$config = $_POST['config'];
$totalPrice = 0;
$componentNames = [];

foreach ($config as $category => $id) {
    if (!$id) continue;

    // Получаем название и цену компонента из БД servachek
    $stmt = $pdo_serv->prepare("SELECT name, price FROM `$category` WHERE id = ?");
    $stmt->execute([$id]);
    $item = $stmt->fetch();

    if ($item) {
        $componentNames[] = $item['name'];
        $totalPrice += (int)$item['price'];
    }
}

// Проверка баланса
$stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
$stmt->execute([$user['id']]);
$balance = (int)($stmt->fetchColumn() ?? 0);

if ($balance < $totalPrice) {
    echo json_encode(['status' => false, 'message' => 'Недостаточно средств на балансе']);
    exit();
}

// Вычитаем сумму из баланса
$pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")->execute([$totalPrice, $user['id']]);

// Сохраняем заказ
$orderName = implode(', ', $componentNames);
$pdo->prepare("INSERT INTO orders (user_id, name, price) VALUES (?, ?, ?)")
    ->execute([$user['id'], $orderName, $totalPrice]);

echo json_encode(['status' => true, 'message' => 'Заказ успешно оформлен!']);
exit();
