<?php
session_start();
require_once 'myssqconect\connect.php';

$user = $_SESSION['user'] ?? null;
if (!$user) {
    header("Location: index.php");
    exit();
}

// Получаем компоненты
$stmt = $pdo->query("SELECT * FROM components ORDER BY category, price");
$components = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $components[$row['category']][] = $row;
}

// Готовые сервера
$serversStmt = $pdo->query("SELECT * FROM ready_servers");
$readyServers = $serversStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Сборка сервера</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f6f8fa;
        }
        .floating-summary {
            position: sticky;
            top: 20px;
        }
    </style>
</head>
<body>
<div class="container-md py-4">

    <!-- Готовые сервера -->
    <h3 class="mb-3">🖥 Готовые решения</h3>
    <div class="row g-3 mb-4">
        <?php foreach ($readyServers as $server): ?>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body small">
                        <h6 class="card-title"><?= htmlspecialchars($server['title']) ?></h6>
                        <p class="card-text"><?= htmlspecialchars($server['description']) ?></p>
                        <p><strong><?= number_format($server['price'], 0, ',', ' ') ?> ₽ / мес</strong></p>
                        <a href="order_ready.php?id=<?= $server['id'] ?>" class="btn btn-outline-success btn-sm w-100">Заказать</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Конфигуратор -->
    <hr class="my-4">
    <h5 class="mb-3">🛠 Конфигуратор сервера</h5>

    <div class="row g-3">
        <!-- Компоненты -->
        <div class="col-md-8">
            <form id="buildForm">
                <?php foreach ($components as $category => $items): ?>
                    <div class="mb-3">
                        <label class="form-label small"><strong><?= htmlspecialchars($category) ?></strong></label>
                        <select class="form-select form-select-sm component-select" name="<?= strtolower($category) ?>" data-category="<?= $category ?>">
                            <option value="" data-price="0">Выберите <?= strtolower($category) ?>...</option>
                            <?php foreach ($items as $item): ?>
                                <option value="<?= $item['id'] ?>" data-price="<?= $item['price'] ?>">
                                    <?= $item['name'] ?> — <?= $item['price'] ?> ₽
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endforeach; ?>

                <button type="submit" class="btn btn-sm btn-primary">🚀 Собрать сервер</button>
            </form>
        </div>

        <!-- Сумма -->
        <div class="col-md-4">
            <div class="card shadow-sm floating-summary">
                <div class="card-body small">
                    <h6 class="card-title">💳 Сумма заказа</h6>
                    <p class="mb-1 text-muted">Итоговая стоимость в месяц:</p>
                    <h5><span id="totalPrice">0</span> ₽ / мес</h5>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const selects = document.querySelectorAll('.component-select');
    const totalPrice = document.getElementById('totalPrice');

    function updatePrice() {
        let sum = 0;
        selects.forEach(select => {
            const selected = select.options[select.selectedIndex];
            sum += parseFloat(selected.dataset.price || 0);
        });
        totalPrice.textContent = sum.toLocaleString('ru-RU');
    }

    selects.forEach(select => {
        select.addEventListener('change', updatePrice);
    });

    document.getElementById('buildForm').addEventListener('submit', function(e) {
        e.preventDefault();
        alert("📦 Заказ отправлен! Здесь будет создание заказа в БД.");
    });
</script>
</body>
</html>
